from setuptools import setup

setup(
    name="bitbots_tf_buffer",
    packages=["bitbots_tf_buffer"],
    zip_safe=True,
    keywords=["ROS"],
    license="MIT",
)
